﻿using PRG3EindopdrachtStudentDb.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PRG3EindopdrachtStudentDb.Create_Files
{
    /// <summary>
    /// Interaction logic for CreateStudent.xaml
    /// </summary>
    public partial class CreateStudent : Window
    {
        static MainWindow mainWindow;
        static DatabaseClass dbHandler;
        int selectedCourseId;
        string studentName;
        string studentClass;

        public CreateStudent()
        {
            InitializeComponent();
        }

        private void FillCbCourses_Click(object sender, RoutedEventArgs e)
        {
            dbHandler = new DatabaseClass();
            DataTable selectedCourses = dbHandler.selectCourses();
            CbCourses.ItemsSource = selectedCourses.DefaultView;
            CbCourses.DisplayMemberPath = "courseName";
        }

        private void BtnCreateStudent_Click(object sender, RoutedEventArgs e)
        {
            if (CbCourses.SelectedItem == null)
            {
                MessageBox.Show("Before continuing, you must choose a course from the 'Course' combobox.", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else if (string.IsNullOrEmpty(TbStudentName.Text))
            {
                MessageBox.Show("Before continuing, you must enter the 'Student name' field.", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else if (string.IsNullOrEmpty(TbClass.Text))
            {
                MessageBox.Show("Before continuing, you must enter the 'Class' field.", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                selectedCourseId = CbCourses.SelectedIndex;
                studentName = TbStudentName.Text;
                studentClass = TbClass.Text;
                dbHandler = new DatabaseClass();
                dbHandler.createStudent(selectedCourseId, studentName, studentClass);
                this.Close();
            }
        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            if(CbCourses.SelectedItem != null || !string.IsNullOrEmpty(TbStudentName.Text) || !string.IsNullOrEmpty(TbClass.Text)) 
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to return to the homepage? Any changes you have made on this screen will then be lost.", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
                if (result == MessageBoxResult.Yes)
                {
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to return to the homepage?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
                if(result == MessageBoxResult.Yes)
                {
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
        }
    }
}