﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using PRG3EindopdrachtStudentDb.Classes;
using PRG3EindopdrachtStudentDb.Create_Files;
using PRG3EindopdrachtStudentDb.Edit_Files;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PRG3EindopdrachtStudentDb
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static DatabaseClass dbHandler;
        static CreateStudent createWindow;
        static EditStudent editWindow ;
        public int chosenStudentId;
        public string courseName;
        public string studentClass;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            createWindow = new CreateStudent();
            createWindow.Show();
            this.Close();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            foreach (var row in dtGrid.SelectedItems)
            {
                DataRowView MyRow = (DataRowView)row;
                chosenStudentId = Convert.ToInt32(MyRow["studentId"]);
                courseName = MyRow["courseName"].ToString();
                studentClass = MyRow["studentClass"].ToString();
            }     
            editWindow = new EditStudent(chosenStudentId, courseName, studentClass);
            editWindow.Show();
            this.Close();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Are you sure you want to delete this student? Deleted data will be lost forever.", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
            if(result == MessageBoxResult.Yes)
            {
                foreach (var row in dtGrid.SelectedItems)
                {
                    DataRowView MyRow = (DataRowView)row;
                    chosenStudentId = Convert.ToInt32(MyRow["studentId"]);
                }
                dbHandler.deleteStudent(chosenStudentId);
                this.Close();
            }
        }

        private void retrieveData_Click(object sender, RoutedEventArgs e)
        {
            dbHandler = new DatabaseClass();
            dbHandler.selectStudentData();
            this.Close();
        }
    }
}