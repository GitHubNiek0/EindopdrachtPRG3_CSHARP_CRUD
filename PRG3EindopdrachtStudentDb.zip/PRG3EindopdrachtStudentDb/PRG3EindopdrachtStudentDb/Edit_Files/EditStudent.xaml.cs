﻿using PRG3EindopdrachtStudentDb.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PRG3EindopdrachtStudentDb.Edit_Files
{
    /// <summary>
    /// Interaction logic for EditStudent.xaml
    /// </summary>
    public partial class EditStudent : Window
    {
        static MainWindow mainWindow;
        static DatabaseClass dbHandler;
        int selectedCourseId;
        string studentClass;
        int studentId;
        string defaultCourse;
        string defaultClass;

        public EditStudent(int studentId, string defaultCourse, string defaultClass)
        {
            InitializeComponent();
            this.studentId = studentId;
            this.defaultCourse = defaultCourse;
            this.defaultClass = defaultClass;
            TbClass.Text = this.defaultClass;
        }

        private void FillCbCourses_Click(object sender, RoutedEventArgs e)
        {
            dbHandler = new DatabaseClass();
            DataTable selectedCourses = dbHandler.selectCourses();
            CbCourses.ItemsSource = selectedCourses.DefaultView;
            CbCourses.DisplayMemberPath = "courseName";
            foreach (DataRowView item in CbCourses.Items) 
            {
                if (item["courseName"].ToString() == defaultCourse)
                {
                    CbCourses.SelectedItem = item;
                }
            }
        }

        private void BtnEditStudent_Click(object sender, RoutedEventArgs e)
        {
            if (CbCourses.SelectedItem == null)
            {
                MessageBox.Show("Before continuing, you must choose a course from the 'Course' combobox.", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else if (string.IsNullOrEmpty(TbClass.Text))
            {
                MessageBox.Show("Before continuing, you must enter the 'Class' field.", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                selectedCourseId = CbCourses.SelectedIndex;
                studentClass = TbClass.Text;
                dbHandler = new DatabaseClass();
                dbHandler.updateStudent(selectedCourseId, studentClass, studentId);
                this.Close();
            }
        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            if (CbCourses.SelectedItem != null || !string.IsNullOrEmpty(TbClass.Text))
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to return to the homepage? Any changes you have made on this screen will then be lost.", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
                if (result == MessageBoxResult.Yes)
                {
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Are you sure you want to return to the homepage?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
                if (result == MessageBoxResult.Yes)
                {
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
        }
    }
}
