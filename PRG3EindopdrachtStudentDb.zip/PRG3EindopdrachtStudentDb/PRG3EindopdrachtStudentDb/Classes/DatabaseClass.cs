﻿using MySql.Data.MySqlClient;
using PRG3EindopdrachtStudentDb.Create_Files;
using PRG3EindopdrachtStudentDb.Edit_Files;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace PRG3EindopdrachtStudentDb.Classes
{
    public class DatabaseClass
    {
        MySqlConnection _connection = new MySqlConnection("Server=localhost;Database=studentsdb;Uid=root;Pwd=;");
        static MainWindow mainWindow;
        MySqlCommand command = new MySqlCommand();
        DataTable selectedStudentData = new DataTable();
        DataTable selectedCourses = new DataTable();
        int rowsAffectedAfterCreation;
        int rowsAffectedAfterEdit;
        int rowsAffectedAfterDeletion;
        DataGrid studentData = new DataGrid();

        public void selectStudentData()
        {
            try
            {
                command = new MySqlCommand("SELECT studentData.studentId, studentData.studentName, courses.courseName, studentData.studentClass FROM studentData INNER JOIN courses ON courses.courseId = studentData.courseId", _connection);
                _connection.Open();
                selectedStudentData.Load(command.ExecuteReader());
                _connection.Close();
                mainWindow = new MainWindow();
                studentData = mainWindow.dtGrid;
                studentData.DataContext = selectedStudentData;
                mainWindow.Show();
            }
            catch (Exception error)
            {
                Console.WriteLine($"Error: {error.Message}");
            }
        }

        public DataTable selectCourses()
        {
            try
            {
                command = new MySqlCommand("SELECT * FROM courses", _connection);
                _connection.Open();
                selectedCourses.Load(command.ExecuteReader());
                _connection.Close();
            }
            catch (Exception error)
            {
                Console.WriteLine($"Error: {error.Message}");
            }
            return selectedCourses;
        }

        public void createStudent(int selectedCourseId, string studentName, string studentClass)
        {
            try
            {
                command = new MySqlCommand("INSERT INTO studentData (courseId, studentName, studentClass) VALUES (?, ?, ?)", _connection);
                command.Parameters.AddWithValue("courseId", selectedCourseId);
                command.Parameters.AddWithValue("studentName", studentName);
                command.Parameters.AddWithValue("studentClass", studentClass);
                _connection.Open();
                rowsAffectedAfterCreation = command.ExecuteNonQuery();
                _connection.Close();
                if (rowsAffectedAfterCreation > 0)
                {
                    MessageBox.Show("Student succesfully created!");
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                }
                else
                {
                    MessageBox.Show("Creation failed.");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine($"Error: {error.Message}");
            }
        }

        public void updateStudent(int selectedCourseId, string studentClass, int chosenStudentId)
        {
            try
            {
                command = new MySqlCommand("UPDATE studentData SET courseId = ?, studentClass = ? WHERE studentId = ?", _connection);
                command.Parameters.AddWithValue("courseId", selectedCourseId);
                command.Parameters.AddWithValue("studentClass", studentClass);
                command.Parameters.AddWithValue("studentId", chosenStudentId);
                _connection.Open();
                rowsAffectedAfterEdit = command.ExecuteNonQuery();
                _connection.Close();
                if (rowsAffectedAfterEdit > 0)
                {
                    MessageBox.Show("Student succesfully updated!");
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine($"Error: {error.Message}");
            }
        }

        public void deleteStudent(int chosenStudentId)
        {
            try
            {
                command = new MySqlCommand("DELETE FROM studentData WHERE studentId = ?", _connection);
                command.Parameters.AddWithValue("studentId", chosenStudentId);
                _connection.Open();
                rowsAffectedAfterDeletion = command.ExecuteNonQuery();
                _connection.Close();
                if (rowsAffectedAfterDeletion > 0)
                {
                    MessageBox.Show("Student succesfully deleted!");
                    mainWindow = new MainWindow();
                    mainWindow.Show();
                }
                else
                {
                    MessageBox.Show("Deletion failed.");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine($"Errror: {error.Message}");
            }
        }
    }
}